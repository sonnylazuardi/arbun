-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 07, 2013 at 08:35 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arbun`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE IF NOT EXISTS `akun` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nim` varchar(40) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `id_fakultas` int(10) NOT NULL,
  `id_jurusan` int(10) NOT NULL,
  `status` int(2) NOT NULL,
  `jen_kelamin` int(2) DEFAULT NULL,
  `wkt_dibuat` int(5) DEFAULT NULL,
  `wkt_diupdate` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas` (`id_fakultas`),
  KEY `idJurusan` (`id_jurusan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `email`, `password`, `nim`, `tgl_lahir`, `id_fakultas`, `id_jurusan`, `status`, `jen_kelamin`, `wkt_dibuat`, `wkt_diupdate`) VALUES
(5, 'Sonny Lazuardi Hermawan', '13511029@std.stei.itb.ac.id', 'arbuniscool', '13511029', '1993-07-31', 1, 1, 1, 0, 0, NULL),
(6, 'joe', 'joe@hoe.com', 'hello', '122124', '2131-01-01', 1, 1, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `id_pengarang` int(10) NOT NULL,
  `tahun` int(10) DEFAULT NULL,
  `jilid` int(5) DEFAULT NULL,
  `penerbit` varchar(80) DEFAULT NULL,
  `ISBN` varchar(12) DEFAULT NULL,
  `abstrak` text,
  `bidang` varchar(50) DEFAULT NULL,
  `link` varchar(150) NOT NULL,
  `view` int(10) DEFAULT NULL,
  `wkt_upload` time NOT NULL,
  `wkt_terbit` time DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idPengarang` (`id_pengarang`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE IF NOT EXISTS `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `word` varchar(20) NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(2, 1357533420, '::1', 'Vvw2o6SA'),
(5, 1357533467, '::1', 'zoz2wpau'),
(6, 1357533468, '::1', 'DucgtdwU'),
(7, 1357533468, '::1', 'l0f3Cro2'),
(8, 1357533573, '::1', 'W7rFZFNZ'),
(9, 1357533574, '::1', 'r4gqAZUV'),
(11, 1357533689, '::1', 'Vl1Tq08o'),
(12, 1357533691, '::1', '3Jgi0CQP'),
(15, 1357533885, '::1', 'gREdP3QF'),
(16, 1357533979, '::1', 'AaUeqNrj'),
(17, 1357534165, '::1', 'NYfdBcHM'),
(18, 1357534454, '::1', 'tYwTvTZK'),
(19, 1357534522, '::1', 'K53fsXik'),
(20, 1357534560, '::1', 'jX1uFINz'),
(21, 1357534629, '::1', 'CO8YMF71'),
(22, 1357534771, '::1', 'k6t9uLmT'),
(23, 1357534912, '::1', 'tDIAVA1w'),
(25, 1357534940, '::1', 'shphxLg6'),
(27, 1357535360, '::1', 'oaAIdg5M'),
(29, 1357535464, '::1', 'G8fu1Nwn'),
(31, 1357535526, '::1', 'k5AVkH8l'),
(33, 1357535632, '::1', 'RzSpppjx'),
(34, 1357535709, '::1', 'NZuHTYNm'),
(43, 1357535886, '::1', 'dfUolBpq'),
(44, 1357535946, '::1', '0LEszY28'),
(46, 1357536030, '::1', 'deflL8zO'),
(48, 1357536551, '::1', 'mfodg'),
(49, 1357536558, '::1', 'dubsf'),
(50, 1357536588, '::1', 'gswoc'),
(54, 1357536619, '::1', 'weeem'),
(55, 1357536770, '::1', 'hjzwr'),
(56, 1357536780, '::1', 'wvtfe'),
(57, 1357536787, '::1', 'ohhuq'),
(58, 1357536801, '::1', 'znenp'),
(61, 1357536928, '::1', 'megck'),
(62, 1357536931, '::1', 'mnbhm'),
(64, 1357537037, '::1', 'hgugh'),
(65, 1357537040, '::1', 'frmxk'),
(66, 1357537181, '::1', 'aqhrz'),
(68, 1357537382, '::1', 'svcwl'),
(69, 1357537394, '::1', 'tnhbq'),
(70, 1357537422, '::1', 'gmrrn'),
(71, 1357537468, '::1', 'hwfus'),
(73, 1357537503, '::1', 'uxplr'),
(77, 1357537564, '::1', 'conjj'),
(78, 1357537584, '::1', 'fslzv'),
(81, 1357537665, '::1', 'ewstq');

-- --------------------------------------------------------

--
-- Table structure for table `fakultas`
--

CREATE TABLE IF NOT EXISTS `fakultas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `singkat` varchar(5) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fakultas`
--

INSERT INTO `fakultas` (`id`, `singkat`, `nama`) VALUES
(1, 'STEI', 'Sekolah Teknik Elektro dan Informatika'),
(2, 'FTI', 'Fakultas Teknologi Industri');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_fakultas` int(10) NOT NULL,
  `singkat` varchar(10) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas2` (`id_fakultas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id`, `id_fakultas`, `singkat`, `nama`) VALUES
(1, 1, 'IF', 'Teknik Informatika'),
(2, 1, 'STI', 'Sistem dan Teknologi Informasi');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori_buku`
--

CREATE TABLE IF NOT EXISTS `kategori_buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_buku` int(10) NOT NULL,
  `id_kategori` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idBuku2` (`id_buku`),
  KEY `idKategori2` (`id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_akun` int(10) NOT NULL,
  `id_buku` int(10) NOT NULL,
  `approved` int(2) DEFAULT NULL,
  `isi` text NOT NULL,
  `wkt_dibuat` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAkun3` (`id_akun`),
  KEY `idBuku4` (`id_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `matkul`
--

CREATE TABLE IF NOT EXISTS `matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `matkul_buku`
--

CREATE TABLE IF NOT EXISTS `matkul_buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_buku` int(10) NOT NULL,
  `id_matkul` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatkulku` (`id_matkul`),
  KEY `idBukuk` (`id_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_akun` int(10) NOT NULL,
  `id_buku` int(10) NOT NULL,
  `rating` int(5) NOT NULL,
  `wkt_dibuat` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAkun` (`id_akun`),
  KEY `idBuku3` (`id_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `akun`
--
ALTER TABLE `akun`
  ADD CONSTRAINT `idFakultas` FOREIGN KEY (`id_fakultas`) REFERENCES `fakultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idJurusan` FOREIGN KEY (`id_jurusan`) REFERENCES `jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `idPengarang` FOREIGN KEY (`id_pengarang`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD CONSTRAINT `idFakultas2` FOREIGN KEY (`id_fakultas`) REFERENCES `fakultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kategori_buku`
--
ALTER TABLE `kategori_buku`
  ADD CONSTRAINT `idBuku2` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idKategori2` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `komentar`
--
ALTER TABLE `komentar`
  ADD CONSTRAINT `idAkun3` FOREIGN KEY (`id_akun`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idBuku4` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `matkul_buku`
--
ALTER TABLE `matkul_buku`
  ADD CONSTRAINT `idBukuk` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idMatkulku` FOREIGN KEY (`id_matkul`) REFERENCES `matkul` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `idAkun` FOREIGN KEY (`id_akun`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idBuku3` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
