-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 10, 2013 at 09:52 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arbun`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE IF NOT EXISTS `akun` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nim` varchar(40) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `fakultas_id` int(10) NOT NULL,
  `jurusan_id` int(10) NOT NULL,
  `status` int(2) NOT NULL,
  `jen_kelamin` int(2) DEFAULT NULL,
  `angkatan` int(5) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas` (`fakultas_id`),
  KEY `idJurusan` (`jurusan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `email`, `password`, `nim`, `tgl_lahir`, `fakultas_id`, `jurusan_id`, `status`, `jen_kelamin`, `angkatan`, `picture`) VALUES
(16, 'Sonny Lazuardi Hermawan', '13511029@std.stei.itb.ac.id', 'sonny', '13511029', '1993-07-31', 1, 1, 1, 0, 2011, 'small1.jpg'),
(17, 'James Bond', 'james@gmail.com', '007', '13511007', '0000-00-00', 1, 1, 1, 0, 2011, 'logo.png'),
(18, 'Dimas Angga', 'dimas@gmail.com', 'dimas', '13511046', '1993-01-01', 1, 1, 1, 0, 2010, 'logo1.png'),
(19, 'Honny', 'coba@coba.com', 'coba', '13511001', '2011-01-01', 1, 1, 0, 0, 2011, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

CREATE TABLE IF NOT EXISTS `bidang` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`id`, `nama`) VALUES
(1, 'Graf'),
(2, 'Pohon'),
(3, '');

-- --------------------------------------------------------

--
-- Table structure for table `bidang_buku`
--

CREATE TABLE IF NOT EXISTS `bidang_buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `bidang_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatkulku` (`bidang_id`),
  KEY `idBukuk` (`buku_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bidang_buku`
--

INSERT INTO `bidang_buku` (`id`, `buku_id`, `bidang_id`) VALUES
(2, 12, 3);

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `akun_id` int(10) NOT NULL,
  `jilid` int(5) DEFAULT NULL,
  `penerbit` varchar(80) DEFAULT NULL,
  `ISBN` varchar(12) DEFAULT NULL,
  `abstrak` text,
  `link` varchar(150) NOT NULL,
  `view` int(10) DEFAULT NULL,
  `tgl_terbit` date DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idPengarang` (`akun_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `judul`, `akun_id`, `jilid`, `penerbit`, `ISBN`, `abstrak`, `link`, `view`, `tgl_terbit`, `status`, `created`, `updated`) VALUES
(2, 'hulk', 16, 0, '', '', 'hulk\r\n', '', NULL, '0000-00-00', 1, '2013-01-09 06:27:16', '2013-01-10 05:22:49'),
(12, 'safadf', 16, 0, '', NULL, 'asfsafsf', '', NULL, '0000-00-00', 1, '2013-01-10 06:14:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `buku_kategori`
--

CREATE TABLE IF NOT EXISTS `buku_kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `kategori_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idBuku2` (`buku_id`),
  KEY `idKategori2` (`kategori_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `buku_kategori`
--

INSERT INTO `buku_kategori` (`id`, `buku_id`, `kategori_id`) VALUES
(4, 12, 2),
(5, 12, 9),
(6, 12, 10),
(7, 12, 11);

-- --------------------------------------------------------

--
-- Table structure for table `buku_matkul`
--

CREATE TABLE IF NOT EXISTS `buku_matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `matkul_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatkulku` (`matkul_id`),
  KEY `idBukuk` (`buku_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `buku_matkul`
--

INSERT INTO `buku_matkul` (`id`, `buku_id`, `matkul_id`) VALUES
(2, 12, 2);

-- --------------------------------------------------------

--
-- Table structure for table `captcha`
--

CREATE TABLE IF NOT EXISTS `captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `captcha_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `word` varchar(20) NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=333 ;

--
-- Dumping data for table `captcha`
--

INSERT INTO `captcha` (`captcha_id`, `captcha_time`, `ip_address`, `word`) VALUES
(261, 1357753947, '::1', 'xjzko'),
(262, 1357755590, '::1', 'sczdh'),
(264, 1357755606, '::1', 'qdlvu'),
(265, 1357755609, '::1', 'oerip'),
(267, 1357756367, '::1', 'tyvxt'),
(268, 1357756453, '::1', 'tdxsv'),
(269, 1357756455, '::1', 'ywhbe'),
(270, 1357756495, '::1', 'lsklf'),
(271, 1357756560, '::1', 'vtzht'),
(273, 1357756664, '::1', 'fagqz'),
(276, 1357756826, '::1', 'hzxyc'),
(277, 1357757467, '::1', 'enpoi'),
(278, 1357757513, '::1', 'tyalq'),
(279, 1357757768, '::1', 'flbac'),
(280, 1357757775, '::1', 'fzpvq'),
(281, 1357757775, '::1', 'zdkhb'),
(282, 1357757776, '::1', 'gewxt'),
(283, 1357757779, '::1', 'qipdb'),
(284, 1357757786, '::1', 'zmfey'),
(285, 1357757791, '::1', 'rmdmt'),
(286, 1357757806, '::1', 'sucrm'),
(287, 1357757810, '::1', 'xgvnk'),
(288, 1357757813, '::1', 'ulpgw'),
(289, 1357757840, '::1', 'lbapd'),
(290, 1357757889, '::1', 'qkfox'),
(291, 1357757894, '::1', 'qunko'),
(292, 1357757898, '::1', 'zphga'),
(293, 1357758272, '::1', 'caydn'),
(294, 1357758276, '::1', 'arghw'),
(295, 1357758279, '::1', 'eguqy'),
(296, 1357758285, '::1', 'chhma'),
(297, 1357758753, '::1', 'pfsrm'),
(298, 1357758755, '::1', 'seeam'),
(299, 1357758759, '::1', 'zbrig'),
(300, 1357758768, '::1', 'cwsng'),
(301, 1357758771, '::1', 'cgnoa'),
(304, 1357759961, '::1', 'tzsrq'),
(305, 1357760035, '::1', 'jvdbk'),
(306, 1357760036, '::1', 'eycgn'),
(307, 1357760039, '::1', 'xhbhq'),
(308, 1357760040, '::1', 'inzvb'),
(309, 1357760044, '::1', 'fpxyd'),
(310, 1357760044, '::1', 'cjvbu'),
(311, 1357760045, '::1', 'htlfd'),
(312, 1357760045, '::1', 'kosuj'),
(313, 1357760054, '::1', 'viexf'),
(314, 1357760066, '::1', 'xmjhi'),
(315, 1357760067, '::1', 'zbtqe'),
(316, 1357760067, '::1', 'faadl'),
(317, 1357760067, '::1', 'jqary'),
(318, 1357760068, '::1', 'ndgez'),
(319, 1357760068, '::1', 'fkopg'),
(320, 1357760069, '::1', 'kisdm'),
(321, 1357760070, '::1', 'yemry'),
(322, 1357760089, '::1', 'pxqcj'),
(323, 1357760094, '::1', 'pqdyy'),
(324, 1357760099, '::1', 'kmxoa'),
(325, 1357760100, '::1', 'zynxt'),
(326, 1357760192, '::1', 'tfzvx'),
(327, 1357760225, '::1', 'spqjm'),
(328, 1357760262, '::1', 'wnidc'),
(329, 1357760386, '::1', 'rdeus'),
(330, 1357760562, '::1', 'fspia'),
(331, 1357762993, '::1', 'pwmjb'),
(332, 1357792671, '::1', 'qlaeg');

-- --------------------------------------------------------

--
-- Table structure for table `fakultas`
--

CREATE TABLE IF NOT EXISTS `fakultas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `singkat` varchar(5) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fakultas`
--

INSERT INTO `fakultas` (`id`, `singkat`, `nama`) VALUES
(1, 'STEI', 'Sekolah Teknik Elektro dan Informatika'),
(2, 'FTI', 'Fakultas Teknologi Industri');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE IF NOT EXISTS `jurusan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fakultas_id` int(10) NOT NULL,
  `singkat` varchar(10) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas2` (`fakultas_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id`, `fakultas_id`, `singkat`, `nama`) VALUES
(1, 1, 'IF', 'Teknik Informatika'),
(2, 1, 'STI', 'Sistem dan Teknologi Informasi');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(1, 'Makalah'),
(2, 'Tugas Akhir'),
(6, 'Hello'),
(7, 'Boys'),
(8, 'Testing'),
(9, 'Coba'),
(10, 'Aja'),
(11, 'Deh');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `approved` int(2) DEFAULT NULL,
  `isi` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAkun3` (`akun_id`),
  KEY `idBuku4` (`buku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `matkul`
--

CREATE TABLE IF NOT EXISTS `matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `matkul`
--

INSERT INTO `matkul` (`id`, `nama`) VALUES
(1, 'Struktur Diskrit'),
(2, '');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `rating` int(5) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAkun` (`akun_id`),
  KEY `idBuku3` (`buku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
