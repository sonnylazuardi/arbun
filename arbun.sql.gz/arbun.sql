-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 14, 2013 at 08:13 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arbun`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

DROP TABLE IF EXISTS `akun`;
CREATE TABLE IF NOT EXISTS `akun` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nim` varchar(40) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `fakultas_id` int(10) NOT NULL,
  `jurusan_id` int(10) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `jen_kelamin` int(2) DEFAULT NULL,
  `angkatan` int(5) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL,
  `approved` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas` (`fakultas_id`),
  KEY `idJurusan` (`jurusan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `email`, `password`, `nim`, `tgl_lahir`, `fakultas_id`, `jurusan_id`, `status`, `jen_kelamin`, `angkatan`, `picture`, `approved`) VALUES
(16, 'Sonny Lazuardi Hermawan', '13511029@std.stei.itb.ac.id', 'sonny', '13511029', '1993-07-31', 1, 1, 1, 0, 2011, 'small1.jpg', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
