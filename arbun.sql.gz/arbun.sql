-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 14, 2013 at 02:09 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arbun`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

DROP TABLE IF EXISTS `akun`;
CREATE TABLE IF NOT EXISTS `akun` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nim` varchar(40) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `fakultas_id` int(10) NOT NULL,
  `jurusan_id` int(10) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `jen_kelamin` int(2) DEFAULT NULL,
  `angkatan` int(5) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL,
  `approved` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas` (`fakultas_id`),
  KEY `idJurusan` (`jurusan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `email`, `password`, `nim`, `tgl_lahir`, `fakultas_id`, `jurusan_id`, `status`, `jen_kelamin`, `angkatan`, `picture`, `approved`) VALUES
(16, 'Sonny Lazuardi Hermawan', '13511029@std.stei.itb.ac.id', 'sonny', '13511029', '1993-07-31', 1, 1, 1, 0, 2011, 'small1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
CREATE TABLE IF NOT EXISTS `award` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

DROP TABLE IF EXISTS `bidang`;
CREATE TABLE IF NOT EXISTS `bidang` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`id`, `nama`) VALUES
(12, 'Huffman'),
(13, 'Pohon'),
(14, 'Stack');

-- --------------------------------------------------------

--
-- Table structure for table `bidang_buku`
--

DROP TABLE IF EXISTS `bidang_buku`;
CREATE TABLE IF NOT EXISTS `bidang_buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `bidang_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatkulku` (`bidang_id`),
  KEY `idBukuk` (`buku_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `bidang_buku`
--

INSERT INTO `bidang_buku` (`id`, `buku_id`, `bidang_id`) VALUES
(17, 26, 12),
(18, 27, 13),
(19, 28, 12),
(20, 29, 14),
(21, 30, 12),
(22, 31, 14);

-- --------------------------------------------------------

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
CREATE TABLE IF NOT EXISTS `bookmark` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `akun_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

DROP TABLE IF EXISTS `buku`;
CREATE TABLE IF NOT EXISTS `buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) NOT NULL,
  `akun_id` int(10) NOT NULL,
  `jilid` int(5) DEFAULT NULL,
  `penerbit` varchar(80) DEFAULT NULL,
  `ISBN` varchar(12) DEFAULT NULL,
  `abstrak` text,
  `link` varchar(150) NOT NULL,
  `view` int(10) DEFAULT NULL,
  `tgl_terbit` date DEFAULT NULL,
  `status` int(5) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `judul`, `akun_id`, `jilid`, `penerbit`, `ISBN`, `abstrak`, `link`, `view`, `tgl_terbit`, `status`, `created`, `updated`) VALUES
(26, 'Huffman Algorithm for Antivirus Quarantine', 16, 0, '', NULL, 'Huffman Algorithm for Antivirus Quarantine ', 'http://localhost/arbun/public/pdf/Makalah-IF2091-2012-031.pdf', 0, '2013-01-12', 0, '2013-01-12 04:32:38', NULL),
(27, 'Implementation of Prim’s Algorithm in Optimizing Drinking Water’s Pipe Distribution Network in South-Central Bandung', 16, 0, '', NULL, 'Implementation of Prim’s Algorithm in Optimizing Drinking Water’s Pipe Distribution Network in South-Central Bandung ', 'http://localhost/arbun/public/pdf/Makalah-IF2091-2012-058.pdf', 0, '2013-01-02', 0, '2013-01-12 06:09:14', NULL),
(28, 'coba aja', 16, 0, '', NULL, 'coba lagi', '', 0, '2013-01-10', 0, '2013-01-12 09:05:03', NULL),
(29, 'Wow keren', 16, 0, '', NULL, 'coba aja lagi', '', 0, '2013-01-12', 0, '2013-01-12 09:32:18', NULL),
(30, 'tambah', 16, 0, '', NULL, 'lagi', '', 0, '2013-01-13', 0, '2013-01-13 08:28:42', NULL),
(31, 'kurang', 16, 0, '', NULL, 'lagi', '', 0, '2013-01-13', 1, '2013-01-13 08:29:03', '2013-01-14 08:39:17');

-- --------------------------------------------------------

--
-- Table structure for table `buku_kategori`
--

DROP TABLE IF EXISTS `buku_kategori`;
CREATE TABLE IF NOT EXISTS `buku_kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `kategori_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idBuku2` (`buku_id`),
  KEY `idKategori2` (`kategori_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `buku_kategori`
--

INSERT INTO `buku_kategori` (`id`, `buku_id`, `kategori_id`) VALUES
(22, 26, 15),
(23, 27, 15),
(24, 28, 16),
(25, 29, 15),
(26, 31, 16);

-- --------------------------------------------------------

--
-- Table structure for table `buku_matkul`
--

DROP TABLE IF EXISTS `buku_matkul`;
CREATE TABLE IF NOT EXISTS `buku_matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `matkul_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatkulku` (`matkul_id`),
  KEY `idBukuk` (`buku_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `buku_matkul`
--

INSERT INTO `buku_matkul` (`id`, `buku_id`, `matkul_id`) VALUES
(17, 26, 11),
(18, 27, 11),
(19, 28, 11),
(20, 29, 12);

-- --------------------------------------------------------

--
-- Table structure for table `fakultas`
--

DROP TABLE IF EXISTS `fakultas`;
CREATE TABLE IF NOT EXISTS `fakultas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `singkat` varchar(5) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fakultas`
--

INSERT INTO `fakultas` (`id`, `singkat`, `nama`) VALUES
(1, 'STEI', 'Sekolah Teknik Elektro dan Informatika'),
(2, 'FTI', 'Fakultas Teknologi Industri');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE IF NOT EXISTS `jurusan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fakultas_id` int(10) NOT NULL,
  `singkat` varchar(10) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFakultas2` (`fakultas_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id`, `fakultas_id`, `singkat`, `nama`) VALUES
(1, 1, 'IF', 'Teknik Informatika'),
(2, 1, 'STI', 'Sistem dan Teknologi Informasi');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(15, 'Makalah'),
(16, 'Tugas Akhir');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

DROP TABLE IF EXISTS `komentar`;
CREATE TABLE IF NOT EXISTS `komentar` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `status` int(2) DEFAULT '0',
  `isi` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAkun3` (`akun_id`),
  KEY `idBuku4` (`buku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `matkul`
--

DROP TABLE IF EXISTS `matkul`;
CREATE TABLE IF NOT EXISTS `matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `matkul`
--

INSERT INTO `matkul` (`id`, `nama`) VALUES
(11, 'Struktur Diskrit'),
(12, 'Alstruk');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `rating` int(5) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAkun` (`akun_id`),
  KEY `idBuku3` (`buku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
