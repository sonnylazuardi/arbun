-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2013 at 05:12 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `arbun`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

DROP TABLE IF EXISTS `akun`;
CREATE TABLE IF NOT EXISTS `akun` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `salt` varchar(100) NOT NULL,
  `nim` varchar(40) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `fakultas_id` int(10) NOT NULL,
  `jurusan_id` int(10) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `jen_kelamin` int(2) DEFAULT NULL,
  `angkatan` int(5) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL,
  `approved` int(1) DEFAULT '0',
  `forget` varchar(100) DEFAULT NULL,
  `view` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `test16` (`fakultas_id`),
  KEY `test17` (`jurusan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `email`, `password`, `salt`, `nim`, `tgl_lahir`, `fakultas_id`, `jurusan_id`, `status`, `jen_kelamin`, `angkatan`, `picture`, `approved`, `forget`, `view`) VALUES
(2, 'test', 'sonnylazuardi@gmail.com', 'cab31c8fe524dd518694edde46b8c04f9c413513', '7573ad73013de450ab5d1d4bf1badd2e', '123', '0123-01-01', 1, 1, 1, 0, 123, '', 1, '', 2),
(3, 'Thea Olivia', '13511001@std.stei.itb.ac.id', '', '', '13511001', '0124-01-01', 1, 1, 1, 1, 2011, '', 1, '', 2),
(4, 'Muhammad Furqan Habibi', '13511002@std.stei.itb.ac.id', '', '', '13511002', '0125-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(5, 'David Setyanugraha', '13511003@std.stei.itb.ac.id', '', '', '13511003', '0126-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(6, 'Lukman Hakim', '13511004@std.stei.itb.ac.id', '', '', '13511004', '0127-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(7, 'Ridho Akbarisanto', '13511005@std.stei.itb.ac.id', '', '', '13511005', '0128-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(8, 'Krisna Fathurahman', '13511006@std.stei.itb.ac.id', '', '', '13511006', '0129-01-01', 1, 1, 1, 0, 2011, '', 1, '', 2),
(9, 'Salvian Reynaldi', '13511007@std.stei.itb.ac.id', '', '', '13511007', '0130-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(10, 'Muhammad Rian Fakhrusy', '13511008@std.stei.itb.ac.id', '', '', '13511008', '0131-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(11, 'Kelvin Valensius', '13511009@std.stei.itb.ac.id', '', '', '13511009', '0132-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(12, 'Bintang Rahmatullah', '13511011@std.stei.itb.ac.id', '', '', '13511011', '0133-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(13, 'Dyah Rahmawati', '13511012@std.stei.itb.ac.id', '', '', '13511012', '0134-01-01', 1, 1, 1, 1, 2011, '', 1, '', 1),
(14, 'Alif Raditya Rochman', '13511013@std.stei.itb.ac.id', '', '', '13511013', '0135-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(15, 'Riandy Rahman Nugraha', '13511014@std.stei.itb.ac.id', '', '', '13511014', '0136-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(16, 'Fransiskus Xaverius Christian', '13511016@std.stei.itb.ac.id', '', '', '13511016', '0137-01-01', 1, 1, 1, 0, 2011, '', 1, '', 2),
(17, 'Rangga Yustian M', '13511017@std.stei.itb.ac.id', '', '', '13511017', '0138-01-01', 1, 1, 1, 0, 2011, '', 1, '', 1),
(18, 'Tito D Kesumo Siregar', '13511018@std.stei.itb.ac.id', '', '', '13511018', '0139-01-01', 1, 1, 1, 0, 2011, '', 1, '', 2),
(19, 'Ignatius Evan Daryanto', '13511019@std.stei.itb.ac.id', '', '', '13511019', '1993-01-01', 1, 1, 1, 0, 2011, '384642_197522190334580_1930107461_n.jpg', 1, '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
CREATE TABLE IF NOT EXISTS `award` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test3` (`buku_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

DROP TABLE IF EXISTS `bidang`;
CREATE TABLE IF NOT EXISTS `bidang` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`id`, `nama`) VALUES
(12, 'Huffman'),
(13, 'Pohon'),
(15, 'Graf'),
(16, 'Kriptografi');

-- --------------------------------------------------------

--
-- Table structure for table `bidang_buku`
--

DROP TABLE IF EXISTS `bidang_buku`;
CREATE TABLE IF NOT EXISTS `bidang_buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `bidang_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatkulku` (`bidang_id`),
  KEY `idBukuk` (`buku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
CREATE TABLE IF NOT EXISTS `bookmark` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `akun_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test8` (`buku_id`),
  KEY `test12` (`akun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bookmark`
--

INSERT INTO `bookmark` (`id`, `buku_id`, `akun_id`) VALUES
(1, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

DROP TABLE IF EXISTS `buku`;
CREATE TABLE IF NOT EXISTS `buku` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) NOT NULL,
  `akun_id` int(10) NOT NULL,
  `jilid` int(5) DEFAULT NULL,
  `penerbit` varchar(80) DEFAULT NULL,
  `ISBN` varchar(12) DEFAULT NULL,
  `abstrak` text,
  `link` varchar(150) NOT NULL,
  `thumb` varchar(150) DEFAULT NULL,
  `view` int(10) DEFAULT '0',
  `tgl_terbit` date DEFAULT NULL,
  `status` int(5) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `tes1` (`akun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `judul`, `akun_id`, `jilid`, `penerbit`, `ISBN`, `abstrak`, `link`, `thumb`, `view`, `tgl_terbit`, `status`, `created`, `updated`) VALUES
(4, 'lorem ipsum', 2, 0, '', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non', '', '', 2, '2013-01-20', 1, '2013-01-20 00:49:14', '2013-01-20 01:45:38'),
(5, 'consectetur adipisicing', 2, 0, '', '', 'Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '', '', 2, '2013-01-20', 1, '2013-01-20 00:49:47', '2013-01-20 01:45:54'),
(6, 'Aplikasi Graf dalam Diagnosis Penyakit Dalam', 2, 0, '', '', 'Pada umumnya penyakit dalam sudah merabah ke seluruh kalangan masyrakat dan tidak menutup kemungkinan kita sendiri dapat terkena penyakit tersebut. Penyakit dalam memiliki jenis yang sangat beragam, seperti contoh yang bisa kita lihat dalam lingkungan sekitar yakni demam berdarah, malaria, dan lainnya. Penyakit – penyakit tersebut dapat dengan mudah menular ke masyarakat, maka dari itu diperlukan diagnosis yang sangat cepat dan tepat untuk mengklasifikasi penyakit tersebut untuk menetukan tindakan penanganan yang tepat dalam menangani penyakit tersebut seperti pengobatan dan tindakan lainnya yang dibutuhkan. Dokter penyakit dalam dilatih untuk memecahkan teka-teki masalah diagnosis dan menangani penyakit dan keadaan kronis parah dimana beberapa penyakit yang berbeda dapat bersimpangan di saat yang sama. Diagnosa penyakit dalam dapat dilakukan dengan menggunakan tenik metode penelusuran, dimana metode penelusuran dapat dilakukan dengan graf untuk memudahkan diagnosa dan penanganan yang harus dilakukan seperti obat dan tindakan yang harus dilakukan.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-003.pdf', '', 2, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(7, 'Graph Theory Applications in Electrical Networks ', 3, 0, '', '', 'The graph is a traditional way to solve problems with\na primitive step-by-step system. So far we have learned\nthat graph theory have solved many problems, one of\nthem is electrical circuits. In electrical circuits, there are\nmany aspects using the graph theory, such as in basic\nelectric circuits into digital computers to Printed Circuit\nBoard (PCB) layout problems.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-006.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(8, 'Bilangan Prima, Uji Keprimaan, dan Berbagai Aplikasi Bilangan Prima ', 4, 0, '', '', 'Pada makalah ini akan dibahas mengenai salah\nsatu obyek studi yang sangat penting di bidang teori\nbilangan, yaitu bilangan prima. Sebagai bilangan yang\nmemiliki sifat keterbagian yang unik, bilangan prima\nmemiliki aplikasi yang luas baik dalam ilmu matematika\nmurni maupun terapan dalam dunia informatika. Oleh\nkarena itu banyak usaha yang dilakukan oleh\nmatematikawan / ilmuan komputer untuk mempelajari\nsifat-sifat bilangan ini dan pemanfaatan dari sifat-sfat\ntersebut. Di antara usaha tersebut adalah pengembangan\nteorema / algoritma baru yang dapat menentukan dengan\npasti keprimaan suatu bilangan.\nDi sini akan dibahas mengenai definisi dan sifat bilangn\nprima, berbagai teori maupun algoritma pengujian\nkeprimaan, serta berbagai aplikasinya di dalam maupun\nluar informatika.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-053.pdf', '', 1, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 05:01:10'),
(9, 'Aplikasi Graf Bipartite dalam Hash Sistem Music Recognition (Aplikasi Shazam) ', 5, 0, '', '', 'Dewasa ini, banyaknya jumlah musik yang\nbermunculan telah menimbulkan suatu kesulitan bagi\nmanusia untuk mengidentifikasi suatu judul musik ketika\nberada di suatu tempat yang memutarkan lagu yang asing\nbaginya. Dengan suatu aplikasi bernama “Shazam”, kini\nmasalah tersebut dapat diselesaikan. Setiap orang dapat\nlangsung mengetahui judul lagu sampai nama penyanyi dari\nsebuah musik yang didengarnya tanpa harus pergi ke toko\nmusik.\nKonsep utama dari aplikasi Shazam ini memanfaatkan\nidentitas unik yang dimiliki oleh setiap lagu dan\nmencocokkannya dengan basis data yang dimilikinya.\nIdentitas unik musik tersebut dikenal dengan nama\nSpectogram. Sistem penyimpanan identitas unik yang\ndimiliki oleh musik tersebut ternyata memanfaatkan prinsip\ndari salah satu jenis graf,yaitu graf bipartite.\nMakalah ini akan membahas penerapan konsep graf\nbipartite dalam pencarian identitas music tersebut terutama\ndengan aplikasi “Shazam”.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-100.pdf', '', 1, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 05:11:55'),
(10, 'Kriptografi Unsur Kimia dalam Tabel Periodik ', 6, 0, '', '', 'Makalah ini membahas tentang teknik\nkriptogra? unsur kimia dalam tabel periodik.\nTabel periodik terdiri atas 118 unsur dapat\ndigunakan sebagai chiperteks dalam suatu\nplainteks menggunakan algoritma enkripsi\ntertentu. Hal ini merupakan hal yang baru\ndigunakan. Penggunaan unsur kimia dida-\nsarkan pada banyaknya jumlah unsur kimia\nyang disertai sifat keperiodikannya sehing-\nga dapat dijadikan sebuah kode dalam me-\nnyimpan sebuah pesan. Selain itu, bentuk\ntabel periodik yang unik juga membuat algo-\nritma ini terlihat berbeda dari yang lain.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-097.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(11, 'Analisis Mengenai Paradoks Permasalahan Monty Hall ', 7, 0, '', '', 'Matematika diskrit adalah cabang matematika\nyang mengkaji benda-benda diskrit. Definisi diskrit adalah\nterdiri atas sejumlah elemen berbeda yang berhingga dan\ntidak berkesinambungan. Yang termasuk bahasan dari\nmatematika diskrit ini antara lain yaitu logika.\nLogika berarti hasil pertimbangan akal pikiran yang\ndiutarakan lewat kata dan dinyatakan dalam bahasa.\nLogika ini sebenarnya adalah bagian dari filsafat, yang\nmenggunakan studi penalaran. Terkadang, penalaran ini\nbertentangan dengan intuisi manusia. Pertentangan ini\nsering disebut dengan paradoks.\nSalah satu contoh paradoks diawali pada sebuah acara di\nAmerika berjudul “Let’s Make a Deal”. Permasalahan ini,\nyaitu diberikan 3 pintu di mana salah satu berisi mobil dan\nsisanya kambing. Pilih 1 pintu, lalu pembawa acara yang\nsudah tahu isi dibalik semua pintu akan membuka pintu\nyang di baliknya terdapat kambing. Lalu pembawa acara\nmenawarkan apakah ingin berganti menjadi pintu lainnya?\nDan apakah berganti pintu ini lebih menguntungkan?\nMakalah ini akan membahas lebih lanjut mengenai\npermasalahan ini yang kemudian sering dikenal dengan\nMonty Hall Problem.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-043.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(12, 'Enskripsi Chiperteks Lord Bacon’s Biliteral Alphabets Menggunakan Pohon ', 8, 0, '', '', 'Lord Bacon’s Biliteral Alphabets merupakan salah satu\nteknik enskripsi plaintext yang terkenal dalam Kriptografi\nselain Caesar’s Chiper dan Skema Shamir’s and Blakley’s.\nDengan menggunakan konsep pohon, chipertext yang\nmenggunakan enskripsi Lord Bacon’s Biliteral Alphabet\ndapat dideskripsikan dengan lebih mudah. Metode-metode\nyang berkaitan dengan prinsip pohon mampu\nmerepresentasikan proses enskripsi dengan lebih mudah.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-073.pdf', '', 1, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 05:00:54'),
(13, 'Algoritma Pengurutan Data Kompleksitas dan Penerapannya', 9, 0, '', '', 'Algoritma-algoritma pengurutan data dalam kajian ilmu\ninformatika, seringkali digunakan untuk menyelesaikan\nberbagai macam persoalan informatika. Dengan semakin\nbervariasinya permasalahan-permasalahan tadi, efisiensi dari\nalgoritma-algoritma pengurutan menjadi amat penting, karena\nalgoritma pengurutan biasanya merupakan sebagian saja dari\nsolusi total sebuah permasalahan di dunia informatika,\nsehingga alangkah baiknya jika proses pengurutan data tidak\nmenjadi batu sandungan dalam proses penyelesaian masalah\nsecara keseluruhan. Algoritma-algoritma pengurutan data\nyang ada saat ini dapat dikelompokkan menjadi 2, yaitu\nmenurut berbasis perbandingan atau tidaknya, atau juga\nmenurut stabil atau tidaknya.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-066.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(14, 'Application of Erdos–Gallai Theorem to Validate Degree Sequence of A Simple Graph ', 11, 0, '', '', 'In Computer Science, we often meet problems\nthat contain graph theory. This paper will give a sample\nproblem of graph theory and how to solve it. This paper is\ndivided into several sections. Section I will introduce the paper.\nSection II will present the problem. Section III is divided into 5\nsection. Section A will talk about some false approaches to\nsolve the problem. Section B will talk about Erd?s–Gallai\nTheorem statement. Section C will discuss about the proof of\nthe theorem. Section D will discuss about how to implement\nthe theorem. Section E will discuss about the complexity of the\nalgorithm. Section IV will show the implementation of the\nalgorithm in the form of code in C++. Section V will conclude\nthe paper.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-011.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(15, 'Aplikasi Penggunaan Graf Pada Sistem Website Video Streaming Youtube ', 12, 0, '', '', 'Makalah ini membahas tentang penaplikasian\ngraf pada jaringan server youtube juga sistem penyebaran\ndan keamanannya', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-087.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(16, 'Graph Theory for Representing the Connection among Users of Social Networks : Facebook, Twitter and Plurk ', 13, 0, '', '', 'This paper is about the graph theory which is\nused in analyzing and describing connection among users of\nsocial networks. Basic theories which is used is the types of\ngraph that consist of simple and unsimple graph, then\ndirected and undirected graph. We discuss several social\nnetworks, they are Facebook, Twitter, and Plurk. The\nconnection among Facebook users can be represented as\nundirected graph, while among Twitter users as directed\ngraph, and among Plurk users we use both, directed and\nundirected graph.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-075.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(17, 'Pengelompokan Organisme Dengan Menggunakan Algoritma Kruskal ', 14, 0, '', '', 'Dengan banyaknya jumlah organisme yang\nmencapai puluhan juta, kita memerlukan suatu cara yang\nmangkus untuk mengelompokkan keseluruhan organisme.\nUntuk menyeselesaikan masalah ini, kita akan mencoba\nmemodelkan permasalahan ini sebagai permasalahan graf.\nPermasalahan\nberubah\nmenjadi\nmodifikasi\ndari\npermasalahan minimum spanning tree. Dengan begitu kita\ndapat menyelesaikan permasalahan dengan algoritma yang\nserupa dengan minimum spanning tree dan kompleksitas\nwaktu yang relatif sama.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-091.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(18, 'Penerapan Logika Fuzzy untuk Menghitung Uang Saku Perhari ', 15, 0, '', '', 'Pada makalah ini penulis akan membahas\nmengenai penerapan logika fuzzy. Logika fuzzy berdasar\npada teori himpunan fuzzy yang memetakan fungsi\nkeanggotaan suatu elemen dalam himpunan dalam rentang\n[0,1]. Logika fuzzy ini akan penulis gunakan untuk\nmenaksir uang saku yang sebaiknya penulis sediakan\nbergantung pada perkiraan konsumsi hari ini (dalam\nrupiah) dan lamanya aktivitas perhari penulis.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-047.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(19, 'Diagnosa Ringan dengan Pohon Keputusan', 16, 0, '', '', 'Pohon sebagai cabang ilmu Struktur Diskrit,\nmemiliki keterkaitan dengan ilmu-ilmu lain dalam\nkehidupan kita. Seperti ilmu kedokteran misalnya. Dalam\nmenganalisis penyakit seorang pasien, secara tidak langsung\ndokter menggunakan ‘pola pikir’ pohon keputusan dalam\nmendiagnosa pasiennya. Dengan memperoleh kondisi pasien\nsebagai keputusan (simpul pohon sebagai keadaan) sampai\nakhirnya dapat mengerucut pada sebuah konklusi penyakit\ntertentu yang diderita pasien (daun pohon sebagai solusi).\nSehingga penyakit tersebut dapat diobati dengan cara\npengobatan yang tepat.\nMakalah ini akan membahas masalah kesehatan umum,\ndengan menggunakan aplikasi pohon keputusan dan ilmu\nkedokteran, sehingga kita sebagai orang awam mengenai\nilmu medis, dapat segera ‘mendiagnosa’ apa penyakit yang\nkita derita harus segera mendapat penanganan pihak medis,\natau dapat diobati sendiri.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-080.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(20, 'Aplikasi Pohon Keputusan dalam Rekrutmen Karyawan ', 17, 0, '', '', 'Rekrutmen karyawan baru bukan hal yang\nmudah untuk dilakukan. Berbagai kriteria diciptakan untuk\nmenentukan kualifikasi karyawan yang diinginkan Namun,\nsering kali perekrut kurang memahami dan menjalankan\nstandard oprational procedure (SOP) rekrutmen karyawan\nbaru sehingga rekrutmen tidak beralan dengan baik. Oleh\nkarena itu, dibutuhkan suatu metode untuk memudahkan\neksekusi SOP yaitu dengan pohon keputusan.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-001.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(21, 'Directed Graph for Finite-State Machine ', 18, 0, '', '', 'Abstract–Finite-state machine is a widely used logic\nabstraction for a system in which the output depends\non the current state of the machine. It turns out that a\nsubset of finite-state machine with certain state table is\nconveniently expressed as simple state diagram, which\nis a directed graph. The state diagram is able to be\nrecognized as input by various algorithms. One\ncommonly and quite important process is to simulate\nthe finite-state machine, whose speed is in linear\ngrowth, but can be reduced to a constant time by pre-\ncomputation and pre-analyze. From the paper, it is\ndeduced that it might be possible that all finite state\nmachine is expressed in a simple state diagram, thus\nallowing a vast number of finite-state machine to be\nsimulated, analyzed, and processed using various\nstandard graph algorithms.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-094.pdf', '', 0, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 01:45:45'),
(22, 'Kriptografi Visual Sederhana Berbasis Nilai Modulo pada Intensitas Warna Gambar RGB', 19, 0, '', '', 'Pada makalah ini akan dijelaskan mengenai\nimplementasi Kriptografi Visual berdasarkan nilai Modulo\nmasing-masing intensitas warna pada gambar RGB.\nKombinasi nilai modulo ini kemudian dikonversi dalam\nheksadesimal yang kemudian diterjemahkan berdasarkan\ntable ASCII. Metode ini tidak akan menjadikan seseorang\ncuriga terhadap gambar yang kita kirim karena perubahan\nwarna yang dilakukan tidak signifikan, sehingga tidak\nterlihat sebagai noise.', 'http://informatika.stei.itb.ac.id/~rinaldi.munir/Matdis/2012-2013/Makalah2012/Makalah-IF2091-2012-038.pdf', '', 1, '2013-01-20', 1, '2013-01-20 01:32:21', '2013-01-20 05:00:22');

-- --------------------------------------------------------

--
-- Table structure for table `buku_kategori`
--

DROP TABLE IF EXISTS `buku_kategori`;
CREATE TABLE IF NOT EXISTS `buku_kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `kategori_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test7` (`buku_id`),
  KEY `test14` (`kategori_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `buku_kategori`
--

INSERT INTO `buku_kategori` (`id`, `buku_id`, `kategori_id`) VALUES
(1, 4, 15),
(3, 5, 15),
(4, 6, 15),
(5, 7, 15),
(6, 8, 15),
(7, 9, 15),
(8, 10, 15),
(9, 11, 15),
(10, 12, 15),
(11, 13, 15),
(12, 14, 15),
(13, 15, 15),
(14, 16, 15),
(15, 17, 15),
(16, 18, 15),
(17, 19, 15),
(18, 20, 15),
(19, 21, 15),
(20, 22, 15);

-- --------------------------------------------------------

--
-- Table structure for table `buku_matkul`
--

DROP TABLE IF EXISTS `buku_matkul`;
CREATE TABLE IF NOT EXISTS `buku_matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `buku_id` int(10) NOT NULL,
  `matkul_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test9` (`buku_id`),
  KEY `test18` (`matkul_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `buku_matkul`
--

INSERT INTO `buku_matkul` (`id`, `buku_id`, `matkul_id`) VALUES
(1, 4, 1),
(2, 5, 1),
(3, 6, 1),
(4, 7, 1),
(5, 8, 1),
(6, 9, 1),
(7, 10, 1),
(8, 11, 1),
(9, 12, 1),
(10, 13, 1),
(12, 14, 1),
(13, 15, 1),
(14, 16, 1),
(15, 17, 1),
(16, 18, 1),
(17, 19, 1),
(18, 20, 1),
(20, 21, 1),
(22, 22, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fakultas`
--

DROP TABLE IF EXISTS `fakultas`;
CREATE TABLE IF NOT EXISTS `fakultas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `singkat` varchar(5) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fakultas`
--

INSERT INTO `fakultas` (`id`, `singkat`, `nama`) VALUES
(1, 'STEI', 'Sekolah Teknik Elektro dan Informatika'),
(2, 'FTI', 'Fakultas Teknologi Industri');

-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE IF NOT EXISTS `jurusan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fakultas_id` int(10) NOT NULL,
  `singkat` varchar(10) DEFAULT NULL,
  `nama` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test19` (`fakultas_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id`, `fakultas_id`, `singkat`, `nama`) VALUES
(1, 1, 'IF', 'Teknik Informatika'),
(2, 1, 'STI', 'Sistem dan Teknologi Informasi');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(15, 'Makalah'),
(16, 'Tugas Akhir');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

DROP TABLE IF EXISTS `komentar`;
CREATE TABLE IF NOT EXISTS `komentar` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `status` int(2) DEFAULT '0',
  `isi` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test4` (`buku_id`),
  KEY `test13` (`akun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `lapor`
--

DROP TABLE IF EXISTS `lapor`;
CREATE TABLE IF NOT EXISTS `lapor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `isi` varchar(500) NOT NULL,
  `is_read` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `test5` (`buku_id`),
  KEY `test11` (`akun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `matkul`
--

DROP TABLE IF EXISTS `matkul`;
CREATE TABLE IF NOT EXISTS `matkul` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `matkul`
--

INSERT INTO `matkul` (`id`, `nama`) VALUES
(1, 'Struktur Diskrit');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun_id` int(10) NOT NULL,
  `buku_id` int(10) NOT NULL,
  `rating` int(5) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `test2` (`buku_id`),
  KEY `test10` (`akun_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `akun`
--
ALTER TABLE `akun`
  ADD CONSTRAINT `test16` FOREIGN KEY (`fakultas_id`) REFERENCES `fakultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test17` FOREIGN KEY (`jurusan_id`) REFERENCES `jurusan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `award`
--
ALTER TABLE `award`
  ADD CONSTRAINT `test3` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bidang_buku`
--
ALTER TABLE `bidang_buku`
  ADD CONSTRAINT `test15` FOREIGN KEY (`bidang_id`) REFERENCES `bidang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test6` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bookmark`
--
ALTER TABLE `bookmark`
  ADD CONSTRAINT `test12` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test8` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `tes1` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `buku_kategori`
--
ALTER TABLE `buku_kategori`
  ADD CONSTRAINT `test14` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test7` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `buku_matkul`
--
ALTER TABLE `buku_matkul`
  ADD CONSTRAINT `test18` FOREIGN KEY (`matkul_id`) REFERENCES `matkul` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test9` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD CONSTRAINT `test19` FOREIGN KEY (`fakultas_id`) REFERENCES `fakultas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `komentar`
--
ALTER TABLE `komentar`
  ADD CONSTRAINT `test13` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test4` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lapor`
--
ALTER TABLE `lapor`
  ADD CONSTRAINT `test11` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test5` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `test10` FOREIGN KEY (`akun_id`) REFERENCES `akun` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `test2` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
